const details = {
  Math: {
    subjectName: "Math",
    numberOfChapter: 1,
    chapters: ["Probability"],
  },
  English: {
    subjectName: "English",
    numberOfChapter: 1,
    chapters: ["Article"],
  },
};

export { details };
