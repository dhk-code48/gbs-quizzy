import Quiz from "./Quiz";
import Loading from "./Loading";
export { Loading, Quiz };
