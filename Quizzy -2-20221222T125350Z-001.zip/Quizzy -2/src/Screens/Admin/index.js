import Admin from "./Admin";

export { Admin };
