import Home from "./Home/Home";
import { Admin } from "./Admin";
import { Start } from "./Start";
import { Quiz } from "./Quiz";
import { Leaderboard } from "./Leaderboard";
import { Users,Search } from "./Users";

export { Admin, Users,Search, Leaderboard, Quiz, Start, Home };
