export const details = [
  {
    type: "Course",
    subjects: [
      { subjectName: "Computer", chapters: ["C"] },
      { subjectName: "Math", chapters: ["Probability"],},
      { subjectName: "English", chapters: ["Articel"],},
    {subjectName:"Biology",chapters:["Animal Kingdom","Vetebrates"] },
    ],
  },
  {
    type: "General Knowledge",
    subjects: [
      {
        subjectName: "Geography",
        
      },
    ],
  },
];
