import Start from "./Start";
import { details } from "./_data";

export { Start, details };
