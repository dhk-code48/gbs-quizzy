import React from "react";
import { Leaderboard } from "..";

const Home = () => {
  return (
    <div className="home">
      <Leaderboard />
    </div>
  );
};

export default Home;
